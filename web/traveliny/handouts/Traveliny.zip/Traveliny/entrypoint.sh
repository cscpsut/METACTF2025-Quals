#!/bin/bash
echo "$FLAG" > /flag.txt
/usr/bin/supervisord